import os
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader
from model import ChessCNN
from data_processing import load_dataset
import numpy as np

def train(csv_path, epochs=10, batch_size=128, lr=1e-3, save_path='models/checkpoint.pt'):
    X, y = load_dataset(csv_path)
    X = torch.from_numpy(X)
    y = torch.from_numpy(y)
    ds = TensorDataset(X, y)
    dl = DataLoader(ds, batch_size=batch_size, shuffle=True, num_workers=0)

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = ChessCNN().to(device)
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=lr)

    for ep in range(1, epochs+1):
        model.train()
        running = 0.0
        for xb, yb in dl:
            xb = xb.to(device)
            yb = yb.to(device)
            optimizer.zero_grad()
            out = model(xb)
            loss = criterion(out, yb)
            loss.backward()
            optimizer.step()
            running += loss.item() * xb.size(0)
        epoch_loss = running / len(ds)
        print(f"Epoch {ep}/{epochs} - loss: {epoch_loss:.4f}")
        # save checkpoint each epoch
        torch.save({'model_state': model.state_dict(), 'epoch': ep}, save_path)

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--data', default='data/chess_dataset.csv')
    parser.add_argument('--epochs', type=int, default=5)
    parser.add_argument('--batch', type=int, default=128)
    args = parser.parse_args()
    train(args.data, epochs=args.epochs, batch_size=args.batch)