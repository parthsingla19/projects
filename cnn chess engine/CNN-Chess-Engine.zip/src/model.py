import torch
import torch.nn as nn

class ChessCNN(nn.Module):
    def __init__(self):
        super().__init__()
        # Input: (batch, 12, 8, 8)
        self.features = nn.Sequential(
            nn.Conv2d(12, 64, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.Conv2d(64, 128, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.Conv2d(128, 128, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.AdaptiveAvgPool2d((1,1))
        )
        self.head = nn.Sequential(
            nn.Flatten(),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Linear(64, 1)  # regression: predicted centipawn eval
        )

    def forward(self, x):
        x = self.features(x)
        x = self.head(x)
        return x.squeeze(-1)