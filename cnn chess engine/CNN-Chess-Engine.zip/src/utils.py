import pandas as pd
import chess

def sample_csv_template(path='data/chess_dataset.csv', n=1000):
    import random
    rows = []
    for _ in range(n):
        board = chess.Board()
        for _ in range(random.randint(0, 20)):
            if board.is_game_over(): break
            mv = random.choice(list(board.legal_moves))
            board.push(mv)
        rows.append({'fen': board.fen(), 'target': random.uniform(-200,200)})
    pd.DataFrame(rows).to_csv(path, index=False)
    print(f"wrote {path}")