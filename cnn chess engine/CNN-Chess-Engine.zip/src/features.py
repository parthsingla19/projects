import chess
import numpy as np

def material_imbalance(board: chess.Board):
    values = {'p':1,'n':3,'b':3,'r':5,'q':9}
    white = 0; black = 0
    for p in board.piece_map().values():
        s = p.symbol()
        if s.isupper():
            white += values.get(s.lower(), 0)
        else:
            black += values.get(s.lower(), 0)
    return white - black

def mobility(board: chess.Board):
    return board.legal_moves.count()

def king_safety(board: chess.Board):
    ks = 0
    for side in [True, False]:
        king_sq = board.king(side)
        if king_sq is None: continue
        attackers = board.attackers(not side, king_sq)
        ks += len(attackers)
    return ks