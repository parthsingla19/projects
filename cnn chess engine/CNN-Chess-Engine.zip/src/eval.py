import torch
import numpy as np
from model import ChessCNN

def evaluate(model_path, X):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = ChessCNN().to(device)
    ckpt = torch.load(model_path, map_location=device)
    model.load_state_dict(ckpt['model_state'])
    model.eval()
    with torch.no_grad():
        X = torch.from_numpy(X).to(device)
        preds = model(X).cpu().numpy()
    return preds