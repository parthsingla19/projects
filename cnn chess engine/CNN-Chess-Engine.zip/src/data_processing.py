import os
import chess
import numpy as np
import pandas as pd

def fen_to_plane(fen: str):
    \"\"\"Convert FEN to a 8x8x12 binary plane representation.\"\"\"
    board = chess.Board(fen)
    planes = np.zeros((12, 8, 8), dtype=np.float32)
    piece_map = board.piece_map()
    piece_to_idx = {
        'P':0,'N':1,'B':2,'R':3,'Q':4,'K':5,
        'p':6,'n':7,'b':8,'r':9,'q':10,'k':11
    }
    for sq, piece in piece_map.items():
        r = 7 - (sq // 8)
        c = sq % 8
        idx = piece_to_idx[piece.symbol()]
        planes[idx, r, c] = 1.0
    return planes

def load_dataset(csv_path):
    \"\"\"CSV expected to have columns: fen, target (e.g. centipawn eval)\"\"\"
    df = pd.read_csv(csv_path)
    X = np.stack([fen_to_plane(f) for f in df['fen'].values])
    y = df['target'].values.astype(np.float32)
    return X, y

if __name__ == '__main__':
    print('data_processing module - convert FEN to planes')