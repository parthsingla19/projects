#!/bin/bash
python -m src.train --data data/chess_dataset.csv --epochs 5 --batch 256
