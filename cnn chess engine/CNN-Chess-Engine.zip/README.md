# CNN-Based Chess Evaluation Engine

**Overview**  
A CNN-based evaluation model for chess positions trained on FEN-encoded board states to predict engine-style evaluations (centipawns). The project includes feature engineering utilities (material imbalance, mobility, king safety), training & evaluation scripts, and dataset helpers.

## Contents
- `src/` — model, training, data processing, features, evaluation
- `data/` — CSV dataset (place your `chess_dataset.csv` here)
- `models/` — saved checkpoints
- `notebooks/` — example notebook for training/analysis

## Quick start
1. Install requirements: `pip install -r requirements.txt`
2. Create a dataset template: `python -m src.utils` (or import `sample_csv_template`)
3. Train: `python -m src.train --data data/chess_dataset.csv --epochs 10`
4. Evaluate: use `src.eval.evaluate('models/checkpoint.pt', X)`

## Notes
- Targets should be engine evaluations in centipawns (float). For mimicry of Stockfish, use large datasets and fine-tune high-error positions (see `src/features.py` for engineered features you can augment input with).
- The CNN here is a compact baseline; for production, experiment with residual blocks, auxiliary heads (side-to-move, material nets), and MSE+Huber losses.

Built by Parth Singla
